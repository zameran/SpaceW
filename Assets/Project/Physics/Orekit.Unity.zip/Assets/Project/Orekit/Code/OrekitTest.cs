﻿using UnityEngine;

using org.orekit.frames;
using org.orekit.orbits;
using org.orekit.time;
using org.orekit.propagation;
using org.orekit.propagation.analytical;

using ZFramework.Math;
using org.orekit.data;
using java.io;
using org.orekit.errors;

public class OrekitTest : MonoBehaviour
{
    private void Start()
    {
        string orekit_data_path = Application.dataPath + "/Resources/Orekit/orekit-data.zip";

        Debug.Log(orekit_data_path);

        try
        {
            DataProvidersManager providers_manager = DataProvidersManager.getInstance();
            providers_manager.clearProviders();

            if (providers_manager.getProviders().size() == 0)
            {
                DataProvider provider;
                provider = new ZipJarCrawler(new File(orekit_data_path));
                providers_manager.addProvider(provider);
            }

            TimeScale timeScale = TimeScalesFactory.getUTC();
            AbsoluteDate date = new AbsoluteDate(2015, 6, 9, 18, 05, 0.0, timeScale);

            Debug.Log(date.toString());
        }
        catch (OrekitException exception)
        {
            Debug.Log(exception.getMessage());
        }

        Frame inertialFrame = FramesFactory.getEME2000();
        TimeScale utc = TimeScalesFactory.getUTC();
        AbsoluteDate initialDate = new AbsoluteDate(2004, 01, 01, 23, 30, 00.000, utc);

        double mu = 3.986004415e+14;

        double a = 24396159;                     // semi major axis in meters
        double e = 0.72831215;                   // eccentricity
        double i = 7 * MathUtils.Deg2Rad;        // inclination
        double omega = 180 * MathUtils.Deg2Rad;  // perigee argument
        double raan = 261 * MathUtils.Deg2Rad;   // right ascension of ascending node
        double lM = 0;                           // mean anomaly

        Orbit initialOrbit = new KeplerianOrbit(a, e, i, omega, raan, lM, PositionAngle.MEAN, inertialFrame, initialDate, mu);
        KeplerianPropagator kepler = new KeplerianPropagator(initialOrbit);
        kepler.setSlaveMode();

        double duration = 600;
        AbsoluteDate finalDate = initialDate.shiftedBy(duration);
        double stepT = 60;
        int cpt = 1;

        for (AbsoluteDate extrapDate = initialDate; extrapDate.compareTo(finalDate) <= 0; extrapDate = extrapDate.shiftedBy(stepT))
        {
            SpacecraftState currentState = kepler.propagate(extrapDate);

            Debug.Log(string.Format("Step: {0}, Time: {1}, {2}", cpt++, currentState.getDate(), currentState.getOrbit()));
        }
    }
}